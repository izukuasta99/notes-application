# MERN_stack_Simple-Application
 A simple Web Application for beginners by using MongoDB, Express, React, Node
 
# Client side-
![image](https://user-images.githubusercontent.com/78893155/149764681-8efaf8d0-3263-4d1d-aaea-8d6f1ad0771b.png)

# Server side-
![image](https://user-images.githubusercontent.com/78893155/149764826-2a10ea99-d74c-41bd-b507-470a4a59bffb.png)

